<?php
$pageTitle = "Certificate Clearance - Employment Agency";
include 'includes/header.php';

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employment_agency";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle certificate verification
if (isset($_POST['verify_certificate'])) {
    $uniqueId = $conn->real_escape_string($_POST['unique_id']);
    $sql = "SELECT * FROM certificates WHERE unique_id = '$uniqueId'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $certificate = $result->fetch_assoc();
        $verificationMessage = "Certificate Verified: Issued to " . $certificate['name'];
    } else {
        $verificationMessage = "Certificate Not Found. Please check the unique ID.";
    }
}
?>

<div class="container py-5">
    <h2 class="text-center mb-4">Certificate Clearance</h2>

    <!-- Step-by-Step Form -->
    <div class="mb-5">
        <h3>Apply for a Certificate</h3>
        <form action="process_certificate.php" method="POST">
            <div class="mb-3">
                <label for="name" class="form-label">Full Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="education" class="form-label">Education</label>
                <input type="text" class="form-control" id="education" name="education" required>
            </div>
            <div class="mb-3">
                <label for="work_experience" class="form-label">Work Experience</label>
                <textarea class="form-control" id="work_experience" name="work_experience" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label for="referees" class="form-label">Referees</label>
                <textarea class="form-control" id="referees" name="referees" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label for="next_of_kin" class="form-label">Next of Kin</label>
                <textarea class="form-control" id="next_of_kin" name="next_of_kin" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label for="payment" class="form-label">Payment (KES 1500)</label>
                <input type="text" class="form-control" id="payment" name="payment" placeholder="Payment Reference">
            </div>
            <button type="submit" class="btn btn-primary">Submit Application</button>
        </form>
    </div>

    <!-- Certificate Verification -->
    <div>
        <h3>Verify a Certificate</h3>
        <form method="POST">
            <div class="mb-3">
                <label for="unique_id" class="form-label">Certificate Unique ID</label>
                <input type="text" class="form-control" id="unique_id" name="unique_id" required>
            </div>
            <button type="submit" name="verify_certificate" class="btn btn-secondary">Verify</button>
        </form>
        <?php if (isset($verificationMessage)): ?>
            <div class="alert alert-info mt-3"><?= $verificationMessage ?></div>
        <?php endif; ?>
    </div>
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>
