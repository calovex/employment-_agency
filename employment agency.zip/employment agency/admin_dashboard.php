<?php
$pageTitle = "Admin Dashboard - Employment Agency";
include 'includes/admin_header.php';

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employment_agency";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch pending applications
$sql = "SELECT * FROM certificates WHERE status = 'Pending'";
$result = $conn->query($sql);

// Approve or Reject Certificates
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $status = $_POST['status'];
    $updateSql = "UPDATE certificates SET status = '$status' WHERE id = $id";
    $conn->query($updateSql);
    header("Location: admin_dashboard.php");
    exit();
}
?>

<div class="container py-5">
    <h2>Pending Certificate Applications</h2>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Education</th>
                <th>Work Experience</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= $row['name'] ?></td>
                    <td><?= $row['education'] ?></td>
                    <td><?= $row['work_experience'] ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                            <button type="submit" name="status" value="Approved" class="btn btn-success btn-sm">Approve</button>
                            <button type="submit" name="status" value="Rejected" class="btn btn-danger btn-sm">Reject</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>

<?php
$conn->close();
include 'includes/footer.php';
?>
