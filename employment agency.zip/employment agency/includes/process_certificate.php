<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "employment_agency";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Capture and store certificate application
$name = $conn->real_escape_string($_POST['name']);
$education = $conn->real_escape_string($_POST['education']);
$workExperience = $conn->real_escape_string($_POST['work_experience']);
$referees = $conn->real_escape_string($_POST['referees']);
$nextOfKin = $conn->real_escape_string($_POST['next_of_kin']);
$payment = $conn->real_escape_string($_POST['payment']);

// Generate unique ID
$uniqueId = uniqid('CERT-', true);

// Store in database
$sql = "INSERT INTO certificates (name, education, work_experience, referees, next_of_kin, unique_id) 
        VALUES ('$name', '$education', '$workExperience', '$referees', '$nextOfKin', '$uniqueId')";

if ($conn->query($sql) === TRUE) {
    echo "Application submitted successfully. Your certificate ID is $uniqueId.";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
