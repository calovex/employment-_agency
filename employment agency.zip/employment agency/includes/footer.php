    <!-- Footer -->
    <footer class="footer bg-dark text-center text-white py-4">
        <div class="container">
            <p>&copy; <?php echo date("Y"); ?> CertifyNow. All rights reserved.</p>
            <p>Follow us on:
                <a href="#" class="text-decoration-none text-white ms-2">Facebook</a> | 
                <a href="#" class="text-decoration-none text-white">Twitter</a> | 
                <a href="#" class="text-decoration-none text-white">LinkedIn</a>
            </p>
        </div>
    </footer>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
